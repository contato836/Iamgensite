import React, { useEffect, useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { blogPosts } from "@/data/blogPosts";
import { Helmet } from "react-helmet";

const DEFAULT_COVER =
  "https://placehold.co/1200x630/1e1e2a/FFF?text=Blog+Cover";

const WHATSAPP_URL =
  "https://wa.me/5511932808687?text=Oi!%20Quero%20abrir%20minha%20empresa.%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20Cidade:%20(SP%2FGuarulhos%2FOsasco%2FSantana%20de%20Parna%C3%ADba)%0A4)%20O%20que%20preciso%20agora:%20(abertura%2Fcont%C3%A1bil%2FDP%2FBPO%2Flegaliza%C3%A7%C3%A3o%2FIR)";

const formatDate = (iso) => {
  try {
    return new Date(iso).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  } catch {
    return iso;
  }
};

const BlogPost = () => {
  const { slug } = useParams();
  const [coverSrc, setCoverSrc] = useState(DEFAULT_COVER);

  const post = useMemo(() => {
    const found = blogPosts.find((p) => p.slug === slug);
    return found || blogPosts[0];
  }, [slug]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  useEffect(() => {
    setCoverSrc(post?.coverImage || DEFAULT_COVER);
  }, [post]);

  const openLink = (href) => {
    const url = href || WHATSAPP_URL;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const renderBlock = (block, idx) => {
    if (!block) return null;

    switch (block.type) {
      case "h1":
        return (
          <h2
            key={idx}
            className="text-2xl md:text-3xl font-bold text-white mt-10 mb-4"
          >
            {block.text}
          </h2>
        );

      case "p":
        return (
          <p key={idx} className="text-gray-300 leading-relaxed text-lg mb-4">
            {block.text}
          </p>
        );

      case "h2":
        return (
          <h2
            key={idx}
            className="text-2xl md:text-3xl font-bold text-white mt-8 mb-4"
          >
            {block.text}
          </h2>
        );

      case "h3":
        return (
          <h3
            key={idx}
            className="text-xl md:text-2xl font-bold text-white mt-6 mb-3"
          >
            {block.text}
          </h3>
        );

      case "ul":
        return (
          <ul
            key={idx}
            className="list-disc pl-6 space-y-2 text-gray-300 text-lg mb-6"
          >
            {block.items?.map((it, i) => (
              <li key={i}>{it}</li>
            ))}
          </ul>
        );

      case "ol":
        return (
          <ol
            key={idx}
            className="list-decimal pl-6 space-y-2 text-gray-300 text-lg mb-6"
          >
            {block.items?.map((it, i) => (
              <li key={i}>{it}</li>
            ))}
          </ol>
        );

      case "cta":
        return (
          <div
            key={idx}
            className="my-8 bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col sm:flex-row gap-4 sm:items-center sm:justify-between"
          >
            <div>
              <p className="text-white font-bold text-lg">{block.text}</p>
              <p className="text-gray-400 mt-1">
                {block.helperText ||
                  "Leva 2 minutos: você me diz sua atividade, sua cidade e o que precisa agora."}
              </p>
            </div>
            <button
              type="button"
              onClick={() => openLink(block.href)}
              className="inline-flex items-center justify-center px-7 py-3 rounded-full bg-accent-purple text-white font-bold hover:bg-accent-purple/90 transition whitespace-nowrap"
            >
              {block.buttonText || "Falar no WhatsApp"}
            </button>
          </div>
        );

      case "faq":
        return (
          <div key={idx} className="mt-6 space-y-3 mb-8">
            {block.items?.map((item) => (
              <details
                key={item.q}
                className="group rounded-2xl bg-white/5 border border-white/10 p-5 open:bg-white/10 transition-colors"
              >
                <summary className="cursor-pointer text-white font-bold list-none flex items-center justify-between">
                  {item.q}
                  <span className="text-accent-purple group-open:rotate-45 transition-transform">
                    +
                  </span>
                </summary>
                <p className="text-gray-300 mt-3 border-t border-white/10 pt-3">
                  {item.a}
                </p>
              </details>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  const seoTitle = post?.seoTitle || `${post?.title || "Blog"} | SOS Contabilidade`;
  const seoDescription = post?.seoDescription || post?.excerpt || "Conteúdo da SOS Contabilidade.";

  return (
    <section className="bg-[#0C0D0D] text-white pt-28 pb-20 min-h-screen">
      <Helmet>
        <title>{seoTitle}</title>
        <meta name="description" content={seoDescription} />

        <meta property="og:title" content={seoTitle} />
        <meta property="og:description" content={seoDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:image" content={coverSrc} />
      </Helmet>

      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          {/* Breadcrumb */}
          <div className="text-sm text-gray-400 mb-6 flex items-center flex-wrap gap-2">
            <Link to="/" className="hover:text-white transition-colors">
              Início
            </Link>
            <span>/</span>
            <Link to="/blog" className="hover:text-white transition-colors">
              Blog
            </Link>
            <span>/</span>
            <span className="text-gray-500 truncate max-w-[240px]">
              {post?.category || "Artigo"}
            </span>
          </div>

          {/* Header */}
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold uppercase leading-tight mb-4">
            {post?.title}
          </h1>

          <div className="flex flex-wrap items-center gap-3 text-sm text-gray-400 mb-6">
            {post?.category ? (
              <>
                <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-white">
                  {post.category}
                </span>
                <span>•</span>
              </>
            ) : null}

            {post?.date ? (
              <>
                <span>{formatDate(post.date)}</span>
                <span>•</span>
              </>
            ) : null}

            {post?.readingTime ? <span>{post.readingTime}</span> : null}
          </div>

          {post?.excerpt ? (
            <p className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8 border-l-4 border-accent-purple pl-4">
              {post.excerpt}
            </p>
          ) : null}

          {/* Cover */}
          <div className="rounded-2xl overflow-hidden border border-white/10 bg-black/20 mb-10">
            <img
              src={coverSrc}
              onError={() => setCoverSrc(DEFAULT_COVER)}
              alt={post?.title || "Capa do post"}
              className="w-full h-auto object-cover max-h-[520px]"
            />
          </div>

          {/* Content Body */}
          <article className="prose prose-invert prose-lg max-w-none">
            {post?.content?.map(renderBlock)}
          </article>

          {/* Footer CTA */}
          <div className="mt-16 border-t border-white/10 pt-8">
            <div className="bg-gradient-to-br from-accent-purple/20 to-transparent p-8 rounded-3xl border border-white/10 text-center">
              <h3 className="text-2xl font-bold text-white mb-3">
                Quer aplicar isso no seu caso hoje?
              </h3>
              <p className="text-gray-300 mb-6 max-w-xl mx-auto">
                Me mande sua atividade e sua cidade no WhatsApp. Eu te digo o caminho certo e os próximos passos.
              </p>
              <button
                type="button"
                onClick={() => openLink(WHATSAPP_URL)}
                className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-accent-purple text-white font-bold text-lg hover:bg-accent-purple/90 transition shadow-lg shadow-accent-purple/20"
              >
                Falar no WhatsApp agora
              </button>
              <p className="text-gray-400 text-sm mt-3">
                Resposta rápida. Sem compromisso.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BlogPost;
