import React, { useEffect } from "react";

const Contact = () => {
  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20or%C3%A7amento%20de%20contabilidade.%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20O%20que%20eu%20preciso%20agora:%20____";

  useEffect(() => {
    window.location.href = WHATSAPP_URL;
  }, []);

  return (
    <section className="min-h-[60vh] bg-[#0C0D0D] flex items-center justify-center px-6">
      <div className="text-center">
        <p className="text-white text-xl font-bold mb-2">Redirecionando para o WhatsApp…</p>
        <p className="text-gray-400">Se não abrir automaticamente, clique no link abaixo.</p>

        <a
          href={WHATSAPP_URL}
          className="inline-block mt-6 px-8 py-4 rounded-full bg-accent-purple text-white font-bold hover:bg-accent-purple/90 transition"
        >
          Abrir WhatsApp
        </a>
      </div>
    </section>
  );
};

export default Contact;
