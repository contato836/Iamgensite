
import React from 'react';
import { Helmet } from 'react-helmet';
import Hero from '@/components/Hero';
import TrustedClients from '@/components/TrustedClients';
import Services from '@/components/Services';
import About from '@/components/About';
import Portfolio from '@/components/Portfolio';
import Testimonials from '@/components/Testimonials';
import Stats from '@/components/Stats';
import CTA from '@/components/CTA';
import SectionAnimator from '@/components/SectionAnimator';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>SOS Contabilidade - Simples, Rápida e Transparente</title>
        <meta name="description" content="Serviços de contabilidade para empresas e pessoa física: Imposto de Renda, abertura/encerramento, contábil mensal, DP, BPO financeiro e legalização. Atendimento direto e sem enrolação." />
      </Helmet>
      <Hero />
      <SectionAnimator><TrustedClients /></SectionAnimator> {/* Clients */}
      <SectionAnimator><Services /></SectionAnimator> {/* Services */}
      <SectionAnimator><Stats /></SectionAnimator> {/* How it Works */}
      <About /> {/* About */}
      <SectionAnimator><Portfolio /></SectionAnimator> {/* Blog Preview (Portfolio contains blog preview) */}
      <SectionAnimator><Testimonials /></SectionAnimator> {/* Testimonials */}
      <SectionAnimator><CTA /></SectionAnimator> {/* Call to Action */}
    </>
  );
};

export default Home;
