
// src/pages/Blog.jsx
import React from "react";
import { Link } from "react-router-dom";
import { blogPosts } from "@/data/blogPosts";
import { Helmet } from 'react-helmet';


const formatDate = (iso) => {
  try {
    return new Date(iso).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  } catch {
    return iso;
  }
};

const Blog = () => {
  const postsSorted = [...blogPosts].sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <section className="bg-[#0C0D0D] text-white pt-28 pb-20">
      <Helmet>
        <title>Blog | SOS Contabilidade</title>
        <meta name="description" content="Artigos práticos sobre contabilidade, impostos e finanças para sua empresa." />
      </Helmet>
      <div className="container mx-auto px-6">
        <div className="max-w-3xl">
          <div className="inline-block px-4 py-1.5 border border-white/20 rounded-full text-sm mb-4 uppercase">
            Blog
          </div>
          <h1 className="text-4xl md:text-6xl font-bold uppercase leading-tight">
            Conteúdos práticos sobre{" "}
            <span className="text-accent-purple">contabilidade</span> e{" "}
            <span className="text-accent-purple">finanças</span>
          </h1>
          <p className="text-gray-400 text-lg mt-4">
            Artigos diretos ao ponto para te ajudar a entender impostos, organizar
            a empresa e tomar decisões com mais segurança.
          </p>
        </div>

        <div className="grid gap-8 mt-12 md:grid-cols-2 lg:grid-cols-3">
          {postsSorted.map((post) => (
            <Link
              key={post.slug}
              to={`/blog/${post.slug}`}
              className="group rounded-2xl overflow-hidden border border-white/10 bg-[#1E1E2A] hover:border-white/20 transition"
            >
              <div className="aspect-[16/9] bg-black/20 overflow-hidden">
                <img
                  src={post.coverImage || "/blog/default.jpg"}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                  loading="lazy"
                />
              </div>

              <div className="p-6">
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10">
                    {post.category}
                  </span>
                  <span>•</span>
                  <span>{formatDate(post.date)}</span>
                  <span>•</span>
                  <span>{post.readingTime}</span>
                </div>

                <h2 className="text-xl font-bold mt-4 group-hover:text-accent-purple transition-colors">
                  {post.title}
                </h2>
                <p className="text-gray-400 mt-2">{post.excerpt}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
