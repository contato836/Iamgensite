
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate, Link } from "react-router-dom";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();

  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20or%C3%A7amento%20de%20contabilidade.%20Meu%20neg%C3%B3cio%20%C3%A9%20____%20e%20preciso%20de%20____.";

  const navLinks = [
    { name: "Serviços", href: "/#services" },
    { name: "Como funciona", href: "/#stats-section" },
    { name: "Sobre", href: "/#about" },
    { name: "Depoimentos", href: "/#testimonials" },
    { name: "Blog", href: "/blog" },
    { name: "Portal do Cliente", href: "https://onvio.com.br/login/#/", external: true },
  ];

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const closeMenu = () => setIsOpen(false);

  const handleSmoothScroll = (e) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute("href") || "";
    const hashIndex = href.indexOf("#");
    const id = hashIndex >= 0 ? href.slice(hashIndex + 1) : "";

    // Vai pra home primeiro (SPA), depois rola até a seção
    navigate("/");
    setTimeout(() => {
      if (id) {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }, 80);

    if (isOpen) closeMenu();
  };

  const handleNavClick = (e, link) => {
    if (link.external) {
      window.open(link.href, "_blank", "noopener,noreferrer");
      if (isOpen) closeMenu();
      e.preventDefault(); // Prevent default link behavior
    } else if (link.href.startsWith("/#")) {
      handleSmoothScroll(e);
    } else {
      // Regular navigation for non-anchor links
      if (isOpen) closeMenu();
    }
  };

  const handleHomeClick = (e) => {
    e.preventDefault();
    navigate("/");
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (isOpen) closeMenu();
  };

  const handleCTA = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
    if (isOpen) closeMenu();
  };

  return (
    <>
      <motion.header
        className={`fixed top-0 left-0 w-full z-50 transition-colors duration-300 ${isScrolled
            ? "bg-[#0C0D0D]/80 backdrop-blur-lg border-b border-white/10"
            : "bg-transparent"
          }`}
      >
        <div className="container mx-auto px-6 h-20 flex justify-between items-center">
          <Link to="/" onClick={handleHomeClick} className="flex items-center">
            <img
              src="https://horizons-cdn.hostinger.com/d4c96338-136d-4501-9c3d-fc3215697c79/1bb576cf2a6a00294eb892ee303c1068.png"
              alt="SOS Contabilidade"
              className="h-16 w-auto"
            />
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              link.external ? (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link)}
                  className="text-gray-300 hover:text-white transition-colors relative group"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {link.name}
                  <span className="absolute left-0 -bottom-1 w-0 h-0.5 bg-accent-purple transition-all duration-300 group-hover:w-full" />
                </a>
              ) : link.href.startsWith("/#") ? (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link)}
                  className="text-gray-300 hover:text-white transition-colors relative group"
                >
                  {link.name}
                  <span className="absolute left-0 -bottom-1 w-0 h-0.5 bg-accent-purple transition-all duration-300 group-hover:w-full" />
                </a>
              ) : (
                <Link
                  key={link.name}
                  to={link.href}
                  className="text-gray-300 hover:text-white transition-colors relative group"
                  onClick={(e) => handleNavClick(e, link)}
                >
                  {link.name}
                  <span className="absolute left-0 -bottom-1 w-0 h-0.5 bg-accent-purple transition-all duration-300 group-hover:w-full" />
                </Link>
              )
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <Button
              className="bg-accent-purple text-white hover:bg-accent-purple/90 group rounded-full"
              onClick={handleCTA}
              type="button"
            >
              Falar no WhatsApp
              <ArrowRight className="ml-2 h-4 w-4 transform transition-transform duration-300 group-hover:translate-x-1" />
            </Button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(true)} className="text-white" type="button">
              <Menu size={28} />
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: "-100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "-100%" }}
            transition={{ duration: 0.45, ease: "easeInOut" }}
            className="fixed inset-0 bg-[#0C0D0D] z-50 md:hidden"
          >
            <div className="container mx-auto px-6 h-full flex flex-col">
              <div className="flex justify-between items-center h-20">
                <Link to="/" onClick={handleHomeClick} className="flex items-center">
                  <img
                    src="https://horizons-cdn.hostinger.com/d4c96338-136d-4501-9c3d-fc3215697c79/1bb576cf2a6a00294eb892ee303c1068.png"
                    alt="SOS Contabilidade"
                    className="h-16 w-auto"
                  />
                </Link>
                <button onClick={closeMenu} className="text-white" type="button">
                  <X size={28} />
                </button>
              </div>

              <nav className="flex-grow flex flex-col justify-center items-center gap-8">
                {navLinks.map((link, index) => (
                  link.external ? (
                    <motion.a
                      key={link.name}
                      href={link.href}
                      onClick={(e) => handleNavClick(e, link)}
                      className="text-3xl font-semibold text-gray-300 hover:text-accent-purple transition-colors"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.15 + index * 0.08 }}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {link.name}
                    </motion.a>
                  ) : link.href.startsWith("/#") ? (
                    <motion.a
                      key={link.name}
                      href={link.href}
                      onClick={(e) => handleNavClick(e, link)}
                      className="text-3xl font-semibold text-gray-300 hover:text-accent-purple transition-colors"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.15 + index * 0.08 }}
                    >
                      {link.name}
                    </motion.a>
                  ) : (
                    <motion.div
                      key={link.name}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.15 + index * 0.08 }}
                    >
                      <Link
                        to={link.href}
                        onClick={() => handleNavClick({ preventDefault: () => {} }, link)} // Pass dummy event for Link
                        className="text-3xl font-semibold text-gray-300 hover:text-accent-purple transition-colors"
                      >
                        {link.name}
                      </Link>
                    </motion.div>
                  )
                ))}
              </nav>

              <div className="py-8 flex flex-col gap-4">
                <Button
                  className="bg-accent-purple text-white hover:bg-accent-purple/90 group w-full text-lg py-6 rounded-full"
                  onClick={handleCTA}
                  type="button"
                >
                  Falar no WhatsApp
                  <ArrowRight className="ml-2 h-4 w-4 transform transition-transform duration-300 group-hover:translate-x-1" />
                </Button>

                <p className="text-center text-gray-400 text-sm">
                  Resposta rápida • Sem compromisso
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;
