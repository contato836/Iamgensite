import React from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, CheckCircle2, MessageCircle } from "lucide-react";

const About = () => {
  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20diagn%C3%B3stico%20r%C3%A1pido%20(2%20min).%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20O%20que%20preciso%20agora:%20(abertura%2Fcont%C3%A1bil%2FDP%2FBPO%2Flegaliza%C3%A7%C3%A3o%2FIR)%0A4)%20Faturamento%20aprox.%20(m%C3%AAs):%20____";

  const WHATSAPP_PROPOSTA_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20uma%20proposta%20de%20contabilidade.%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20O%20que%20preciso%20agora:%20(abertura%2Fcont%C3%A1bil%2FDP%2FBPO%2Flegaliza%C3%A7%C3%A3o%2FIR)%0A4)%20Faturamento%20aprox.%20(m%C3%AAs):%20____";

  const handleWhatsApp = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  const handleWhatsAppProposta = () => {
    window.open(WHATSAPP_PROPOSTA_URL, "_blank", "noopener,noreferrer");
  };

  const bullets = [
    "Atendimento direto no WhatsApp (sem ficar pulando de setor)",
    "Checklist simples do que enviar e quando (sem “contabilês”)",
    "Prazos e obrigações acompanhados com avisos do mês",
    "Você entende o que está sendo feito e o que está pagando",
  ];

  return (
    <section id="about" className="py-24 bg-[#0C0D0D] overflow-hidden">
      <div className="container mx-auto px-6">
        {/* Bloco 1 */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="rounded-2xl overflow-hidden aspect-[4/3]">
              <img
                className="w-full h-full object-cover"
                alt="Atendimento e organização contábil"
                src="https://horizons-cdn.hostinger.com/d4c96338-136d-4501-9c3d-fc3215697c79/charlesdeluvio-lks7vei-eag-unsplash-7Or6F.jpg"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-full mb-6">
              <MessageCircle className="w-4 h-4 text-accent-purple" />
              <span className="text-sm text-gray-300">
                Diagnóstico rápido no WhatsApp (sem compromisso)
              </span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-5 leading-tight text-white uppercase">
              Contabilidade com <span className="text-accent-purple">clareza</span> e rotina em dia
            </h2>

            <p className="text-lg text-gray-400 mb-8">
              Se você vive na correria de prazo, não sabe o que precisa enviar e fica inseguro
              com impostos/obrigações, eu organizo a sua rotina e te explico de forma simples
              o que está acontecendo — sem enrolação.
            </p>

            <div className="space-y-4">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  Você fala com quem resolve
                </h3>
                <p className="text-lg text-gray-400">
                  Atendimento direto no WhatsApp, com retorno rápido para você não ficar travado.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  Menos dúvidas, mais previsibilidade
                </h3>
                <p className="text-lg text-gray-400">
                  Checklist simples, prazos acompanhados e orientação clara do que fazer mês a mês.
                </p>
              </div>

              {/* CTA principal + secundário */}
              <div className="pt-3 flex flex-col sm:flex-row gap-3 sm:items-center">
                <button
                  onClick={handleWhatsApp}
                  type="button"
                  className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-accent-purple text-white font-bold text-lg hover:bg-accent-purple/90 transition"
                >
                  Quero um diagnóstico no WhatsApp
                  <ArrowUpRight className="ml-2 w-5 h-5" />
                </button>

                <button
                  onClick={handleWhatsAppProposta}
                  type="button"
                  className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-white/10 border border-white/20 text-white font-bold text-lg hover:bg-white/15 transition"
                >
                  Pedir proposta
                </button>
              </div>

              <p className="text-gray-400 text-sm mt-3">
                Leva 2 minutos: você me diz seu tipo de negócio e o que precisa agora.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Bloco 2 */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mt-24">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="lg:order-last"
          >
            <div className="rounded-2xl overflow-hidden aspect-[4/3]">
              <img
                className="w-full h-full object-cover"
                alt="Planejamento e acompanhamento"
                src="https://horizons-cdn.hostinger.com/d4c96338-136d-4501-9c3d-fc3215697c79/michael-t-rxri-ho62y4-unsplash-2-tvxRc.jpg"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-5 leading-tight text-white uppercase">
              Você cuida do negócio. Eu cuido da{" "}
              <span className="text-accent-purple">organização</span>
            </h2>

            <p className="text-lg text-gray-400 mb-7">
              Atendo empresas e pessoa física (IR), com soluções para contabilidade mensal,
              departamento pessoal, BPO financeiro e legalização — sempre com uma rotina simples
              e acompanhada.
            </p>

            <div className="grid gap-3">
              {bullets.map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-accent-purple mt-0.5" />
                  <p className="text-gray-300">{item}</p>
                </div>
              ))}
            </div>

            <div className="mt-10 bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col sm:flex-row gap-5 sm:items-center sm:justify-between">
              <div>
                <p className="text-white font-bold text-xl">
                  Me diga seu cenário e eu te direciono o melhor caminho
                </p>
                <p className="text-gray-400 mt-1">
                  Abertura, contábil, DP, BPO, legalização ou IR — eu te digo por onde começar.
                </p>
              </div>

              <button
                onClick={handleWhatsApp}
                type="button"
                className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-accent-purple text-white font-bold text-lg hover:bg-accent-purple/90 transition"
              >
                Falar agora no WhatsApp
                <ArrowUpRight className="ml-2 w-5 h-5" />
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
