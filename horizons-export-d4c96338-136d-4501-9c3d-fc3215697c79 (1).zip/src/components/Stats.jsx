import React, { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";

const AnimatedCounter = ({ to, suffix }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.5 });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;

    const duration = 900;
    const steps = 60;
    const interval = duration / steps;

    const isDecimal = to % 1 !== 0;
    const increment = isDecimal ? to / steps : Math.max(1, Math.ceil(to / steps));

    let current = 0;

    const timer = setInterval(() => {
      current += increment;

      if (current >= to) {
        setCount(to);
        clearInterval(timer);
      } else {
        if (isDecimal) setCount(parseFloat(current.toFixed(1)));
        else setCount(Math.ceil(current));
      }
    }, interval);

    return () => clearInterval(timer);
  }, [isInView, to]);

  return (
    <span ref={ref}>
      {count}
      {suffix}
    </span>
  );
};

const steps = [
  {
    value: 1,
    suffix: "",
    label: "Diagnóstico rápido",
    description:
      "Você explica sua situação e nós te orientamos o melhor caminho (contábil, DP, BPO, legalização, abertura/encerramento ou IR).",
  },
  {
    value: 2,
    suffix: "",
    label: "Checklist + prazos",
    description:
      "Você recebe um checklist simples do que enviar e os prazos, sem burocracia e sem “contabilês”.",
  },
  {
    value: 3,
    suffix: "",
    label: "Rotina acompanhada",
    description:
      "Acompanhamos obrigações e avisos importantes para manter tudo organizado e evitar surpresas no mês.",
  },
  {
    value: 4,
    suffix: "",
    label: "Suporte no WhatsApp",
    description:
      "Dúvidas e ajustes do dia a dia com resposta direta para você não ficar travado.",
  },
];

const Stats = () => {
  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20direcionamento%20de%20contabilidade.%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20O%20que%20eu%20preciso%20agora:%20(abertura%2Fcont%C3%A1bil%2FDP%2FBPO%2Flegaliza%C3%A7%C3%A3o%2FIR)%0A4)%20Cidade/UF:%20____";

  const handleWhatsApp = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  return (
    <section id="stats-section" className="py-24 bg-[#0C0D0D]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white uppercase">
              COMO <span className="text-accent-purple">FUNCIONA</span>
            </h2>
          </div>

          <div className="flex items-end">
            <p className="text-lg text-gray-400 max-w-md">
              Um processo simples em 4 passos para organizar sua rotina e tirar dúvidas com rapidez.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <div
              key={step.label}
              className="bg-[#1E1E2A] p-8 rounded-2xl h-full border border-white/10"
            >
              <div className="text-5xl md:text-6xl font-bold text-white mb-6">
                <AnimatedCounter to={step.value} suffix={step.suffix} />
              </div>

              <h3 className="text-xl font-bold text-white mb-2">{step.label}</h3>
              <p className="text-gray-400">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col sm:flex-row gap-6 sm:items-center sm:justify-between">
          <div>
            <p className="text-white font-bold text-xl">Quer um direcionamento rápido?</p>
            <p className="text-gray-400 mt-1">
              Chame no WhatsApp e receba um passo a passo do que fazer no seu caso.
            </p>
          </div>

          <div className="flex flex-col items-start sm:items-end gap-2">
            <button
              onClick={handleWhatsApp}
              type="button"
              className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-accent-purple text-white font-bold text-lg hover:bg-accent-purple/90 transition"
            >
              Falar no WhatsApp
            </button>
            <p className="text-gray-400 text-sm">Resposta rápida • Sem compromisso</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Stats;