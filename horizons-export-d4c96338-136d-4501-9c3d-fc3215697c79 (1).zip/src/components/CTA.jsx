import React from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedCtaBackground from "@/components/AnimatedCtaBackground";

const CTA = () => {
  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20or%C3%A7amento%20de%20contabilidade.%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20O%20que%20eu%20preciso%20agora:%20____";

  const handleCTAClick = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  const handleViewServices = () => {
    const el = document.getElementById("services");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="cta" className="relative py-32 overflow-hidden">
      <AnimatedCtaBackground />
      <div className="absolute inset-0 bg-black/40"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight uppercase">
            Quer <span className="text-accent-purple">clareza</span> e rotina organizada na contabilidade?
          </h2>

          <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
            Me chame no WhatsApp. Eu te digo o melhor caminho e o que preciso de você para começar.
          </p>

          <div className="flex flex-col items-center gap-4">
            <Button
              onClick={handleCTAClick}
              size="lg"
              className="bg-accent-purple hover:bg-accent-purple/90 text-white font-bold px-10 py-7 text-xl rounded-full group"
              type="button"
            >
              Falar no WhatsApp
              <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-1.5 transition-transform" />
            </Button>

            <button
              type="button"
              onClick={handleViewServices}
              className="text-gray-300 hover:text-white transition underline underline-offset-4"
            >
              Ver serviços
            </button>

            <p className="text-gray-400 text-sm">
              Resposta rápida • Sem compromisso
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
