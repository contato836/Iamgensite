import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { useLocation } from "react-router-dom";

const services = [
  {
    slug: "imposto-de-renda",
    title: "Imposto de Renda",
    description:
      "Declaração completa (PF/PJ), conferência de documentos e revisão para reduzir riscos e evitar cair em malha fina.",
  },
  {
    slug: "abertura-e-encerramento",
    title: "Abertura e Encerramento de Empresa",
    description:
      "Abertura com enquadramento correto e processo rápido. Encerramento/baixa com orientação e regularização do que for necessário.",
  },
  {
    slug: "contabilidade-empresarial",
    title: "Contabilidade Empresarial",
    description:
      "Rotina contábil e fiscal organizada, impostos e obrigações em dia, com atendimento direto para você entender o que está pagando.",
  },
  {
    slug: "departamento-pessoal",
    title: "Departamento Pessoal",
    description:
      "Admissão, folha de pagamento, pró-labore, férias, rescisões e eSocial com acompanhamento para manter sua empresa regular e sem surpresas.",
  },
  {
    slug: "bpo-financeiro",
    title: "BPO Financeiro",
    description:
      "Organização do financeiro, lançamentos, conciliação e relatórios para você ter visão clara do caixa e tomar decisões com segurança.",
  },
  {
    slug: "legalizacao",
    title: "Legalização e Regularização",
    description:
      "Alterações contratuais, regularização de pendências, certidões e suporte para manter o CNPJ regular em todos os órgãos.",
  },
];

const Services = () => {
  const location = useLocation();
  const [activeIndex, setActiveIndex] = useState(null);

  const cardRefs = useRef([]);
  cardRefs.current = [];

  const addToRefs = (el) => {
    if (el && !cardRefs.current.includes(el)) cardRefs.current.push(el);
  };

  const serviceIndexBySlug = useMemo(() => {
    const map = new Map();
    services.forEach((s, i) => map.set(s.slug, i));
    return map;
  }, []);

  const handleServiceClick = (index) => {
    setActiveIndex((prev) => (prev === index ? null : index));
  };

  // 🔥 Abre serviço via URL: /?service=bpo-financeiro#services
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const slug = params.get("service");

    if (!slug) return;

    const index = serviceIndexBySlug.get(slug);
    if (index === undefined) return;

    setActiveIndex(index);

    // scroll suave até o item aberto
    setTimeout(() => {
      const el = cardRefs.current[index];
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 220);
  }, [location.search, serviceIndexBySlug]);

  const filterTags = [
    "Imposto de Renda",
    "Empresas",
    "Contabilidade",
    "Departamento Pessoal",
    "BPO Financeiro",
    "Legalização",
  ];

  return (
    <section id="services" className="py-24 bg-[#0C0D0D]">
      <div className="container mx-auto px-6 relative z-10">
        <div className="mb-16">
          <h2 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight text-white uppercase">
            NOSSOS <span className="text-accent-purple">SERVIÇOS</span>
          </h2>

          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mt-4">
            Soluções contábeis para manter sua empresa regular, com atendimento direto e processos simples.
          </p>

          <div className="flex flex-wrap gap-3 mt-8">
            {filterTags.map((tag) => (
              <button
                key={tag}
                type="button"
                className="px-5 py-2 border border-gray-600 rounded-full text-gray-400 cursor-default uppercase"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        <div className="border-t border-gray-800">
          {services.map((service, index) => (
            <div
              key={service.slug}
              className="border-b border-gray-800"
              ref={addToRefs}
            >
              <div
                className="flex justify-between items-center cursor-pointer py-8 group"
                onClick={() => handleServiceClick(index)}
                role="button"
                tabIndex={0}
              >
                <div className="flex items-center gap-4">
                  <h3
                    className={`text-3xl md:text-5xl font-bold transition-colors duration-300 ${
                      activeIndex === index
                        ? "text-white"
                        : "text-gray-600 group-hover:text-gray-400"
                    }`}
                  >
                    {service.title}
                  </h3>

                  {activeIndex === index && (
                    <motion.div
                      className="w-4 h-4 bg-accent-purple rounded-full"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                    />
                  )}
                </div>

                <motion.div
                  className="text-accent-purple"
                  animate={{ rotate: activeIndex === index ? 45 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Plus
                    size={40}
                    className={`${
                      activeIndex === index
                        ? "text-accent-purple"
                        : "text-gray-600 group-hover:text-gray-400"
                    } transition-colors`}
                  />
                </motion.div>
              </div>

              <AnimatePresence>
                {activeIndex === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0, y: -16 }}
                    animate={{ opacity: 1, height: "auto", y: 0 }}
                    exit={{ opacity: 0, height: 0, y: -16 }}
                    transition={{ duration: 0.35, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="pb-8 pr-16">
                      <p className="text-lg text-gray-400 max-w-2xl">
                        {service.description}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
