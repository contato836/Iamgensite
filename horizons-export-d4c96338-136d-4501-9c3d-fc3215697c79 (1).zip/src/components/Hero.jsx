import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedHeroBackground from "@/components/AnimatedHeroBackground";

const Hero = () => {
  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20or%C3%A7amento%20de%20contabilidade.%20Meu%20neg%C3%B3cio%20%C3%A9%20____%20e%20preciso%20de%20____.";

  const handleCTAClick = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  const handleViewServices = () => {
    const el = document.getElementById("services");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <AnimatedHeroBackground />
      <div className="absolute inset-0 bg-black/50"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-left md:text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-accent-purple/10 border border-accent-purple/20 rounded-full mb-7"
          >
            <Sparkles className="w-4 h-4 text-accent-purple" />
            <span className="text-sm text-[#c5b8ff]">
              Atendimento direto com contador
            </span>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold mb-5 leading-tight text-white"
          >
            Contabilidade simples, rápida e sem enrolação
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="text-lg md:text-2xl text-gray-300 mb-6 max-w-3xl mx-auto"
          >
            Abertura/encerramento, contábil mensal, DP, BPO financeiro e Imposto de Renda — com orientação clara e sem enrolação.
          </motion.p>

          {/* Proof chips */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.38 }}
            className="flex flex-wrap gap-3 mb-8 justify-start md:justify-center"
          >
            <span className="px-4 py-2 rounded-full border border-white/10 bg-white/5 text-gray-200 text-sm">
              Empresas e Pessoa Física
            </span>
            <span className="px-4 py-2 rounded-full border border-white/10 bg-white/5 text-gray-200 text-sm">
              Simples Nacional e Lucro Presumido
            </span>
            <span className="px-4 py-2 rounded-full border border-white/10 bg-white/5 text-gray-200 text-sm">
              Fale Direto com o Contador
            </span>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.45 }}
            className="flex flex-col sm:flex-row gap-4 justify-start md:justify-center items-start md:items-center"
          >
            <Button
              onClick={handleCTAClick}
              size="lg"
              className="bg-accent-purple hover:bg-accent-purple/90 text-white font-bold px-8 py-6 text-lg rounded-full group"
            >
              Falar com o contador agora
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>

            <button
              type="button"
              onClick={handleViewServices}
              className="text-gray-300 hover:text-white transition text-base underline underline-offset-4"
            >
              Ver serviços
            </button>
          </motion.div>

          {/* Microcopy */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="text-gray-400 text-sm mt-3 md:text-center"
          >
            Resposta rápida • Sem compromisso
          </motion.p>
        </div>
      </div>
    </section>
  );
};

export default Hero;