
import React, { useMemo } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, ArrowRight } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { blogPosts } from "@/data/blogPosts";

const DEFAULT_COVER =
  "https://github.com/contato836/Iamgensite/blob/102aab4f8b3ac8cdb163cb4dcaf0dc72652c3d49/ABERTURA%20DE%20EMPRESA.png";

const Portfolio = () => {
  const navigate = useNavigate();

  const formatDate = (iso) => {
    try {
      return new Date(iso).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
    } catch {
      return iso || "";
    }
  };

  const latestPosts = useMemo(() => {
    const list = Array.isArray(blogPosts) ? [...blogPosts] : [];
    list.sort((a, b) => new Date(b?.date || 0) - new Date(a?.date || 0));

    return list.slice(0, 3).map((p) => ({
      ...p,
      cover: p.coverImage || DEFAULT_COVER, // ✅ usa o coverImage do post
    }));
  }, []);

  return (
    <section id="blog" className="py-24 bg-[#0C0D0D]">
      <div className="container mx-auto px-6">
        <div className="flex flex-wrap justify-between items-end gap-8 mb-14">
          <div className="w-full lg:w-1/2">
            <div className="inline-block px-4 py-1.5 border border-white/20 rounded-full text-sm mb-4 uppercase">
              Blog
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight uppercase">
              Últimos conteúdos sobre{" "}
              <span className="text-accent-purple">contabilidade</span>
            </h2>
          </div>

          <div className="w-full lg:w-1/3">
            <p className="text-lg text-gray-400">
              Textos diretos ao ponto para te ajudar a entender impostos, organizar a empresa
              e decidir com mais segurança.
            </p>

            <div className="mt-6">
              <Link
                to="/blog"
                className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-white/10 border border-white/15 text-white font-bold hover:bg-white/15 transition group"
              >
                Ver todos
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {latestPosts.map((post, idx) => (
            <motion.article
              key={post.slug || idx}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.55, ease: "easeOut" }}
              className="group relative rounded-2xl overflow-hidden cursor-pointer border border-white/10 bg-white/5"
              onClick={() => navigate(`/blog/${post.slug}`)}
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  alt={post.title}
                  src={post.cover || DEFAULT_COVER}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = DEFAULT_COVER;
                  }}
                />

                {/* Gradient overlay for better text readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/60 to-transparent" />

                <div className="absolute top-4 left-4 z-10">
                  <span className="inline-flex items-center px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-xs text-white font-medium shadow-sm">
                    {post.category || "Artigo"}
                  </span>
                </div>

                <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-sm p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <ArrowUpRight className="w-5 h-5 text-white" />
                </div>

                <div className="absolute bottom-0 left-0 p-6 w-full z-10">
                  <h3 className="text-xl font-bold text-white mb-2 leading-tight drop-shadow-md">
                    {post.title}
                  </h3>

                  <p className="text-gray-200 text-sm leading-relaxed line-clamp-2 drop-shadow-sm mb-4">
                    {post.excerpt}
                  </p>

                  <div className="flex items-center gap-2 text-xs text-gray-300 font-medium">
                    <span>{formatDate(post.date)}</span>
                    <span className="opacity-60">•</span>
                    <span>{post.readingTime || "—"}</span>
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
