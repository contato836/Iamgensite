import React, { useRef, useState, useEffect } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Mariana S.",
    content:
      "Antes eu sempre descobria coisa em cima da hora. Agora eu sei o que preciso enviar e quando — ficou bem mais leve no mês.",
  },
  {
    id: 2,
    name: "Rafael C.",
    content:
      "Eu tinha receio de trocar de contador e virar bagunça. Foi simples: organizaram tudo e hoje eu tenho uma rotina bem clara.",
  },
  {
    id: 3,
    name: "Ana P.",
    content:
      "Eu estava perdida na abertura. Explicaram o básico de um jeito fácil, cuidaram do processo e depois continuaram acompanhando.",
  },
  {
    id: 4,
    name: "Bruno M.",
    content:
      "Com folha e eSocial eu sempre ficava inseguro. Agora eu mando as informações e recebo orientação do que precisa ajustar.",
  },
  {
    id: 5,
    name: "Juliana R.",
    content:
      "No Imposto de Renda eu tinha medo de errar. Pediram os documentos certos, tiraram minhas dúvidas e revisaram tudo antes de enviar.",
  },
  {
    id: 6,
    name: "Lucas T.",
    content:
      "Eu não tinha visão do caixa de verdade. Com o BPO ficou organizado e eu consigo enxergar o financeiro sem complicar.",
  },
];

const Testimonials = () => {
  const scrollContainerRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(1);

  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Vi%20os%20depoimentos%20e%20quero%20entender%20como%20funciona%20a%20contabilidade%20para%20o%20meu%20caso.%0A%0A1)%20Meu%20neg%C3%B3cio%20%C3%A9:%20____%0A2)%20Tenho%20funcion%C3%A1rios?%20(sim/n%C3%A3o)%0A3)%20O%20que%20eu%20preciso%20agora:%20____";

  useEffect(() => {
    const updateItemsPerPage = () => {
      setItemsPerPage(window.innerWidth >= 768 ? 2 : 1);
    };
    updateItemsPerPage();
    window.addEventListener("resize", updateItemsPerPage);
    return () => window.removeEventListener("resize", updateItemsPerPage);
  }, []);

  const canScrollLeft = currentIndex > 0;
  const canScrollRight = currentIndex < testimonials.length - itemsPerPage;

  const scroll = (direction) => {
    let newIndex = currentIndex;

    if (direction === "left" && canScrollLeft) {
      newIndex = Math.max(0, currentIndex - 1);
    } else if (direction === "right" && canScrollRight) {
      newIndex = Math.min(testimonials.length - itemsPerPage, currentIndex + 1);
    }

    if (newIndex !== currentIndex) {
      setCurrentIndex(newIndex);

      if (scrollContainerRef.current) {
        const card = scrollContainerRef.current.children[newIndex];
        if (card) {
          scrollContainerRef.current.scrollTo({
            left: card.offsetLeft,
            behavior: "smooth",
          });
        }
      }
    }
  };

  const handleCTA = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  return (
    <section id="testimonials" className="py-24 bg-[#0C0D0D] overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight uppercase max-w-xl">
            Quem já organizou a rotina com a{" "}
            <span className="text-accent-purple">gente</span>
          </h2>

          <div className="hidden md:flex gap-4">
            <button
              onClick={() => scroll("left")}
              disabled={!canScrollLeft}
              className="p-3 rounded-full bg-[#1E1E2A] border border-white/10 text-white hover:bg-white/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Scroll left"
              type="button"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <button
              onClick={() => scroll("right")}
              disabled={!canScrollRight}
              className="p-3 rounded-full bg-[#1E1E2A] border border-white/10 text-white hover:bg-white/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Scroll right"
              type="button"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div
          ref={scrollContainerRef}
          className="flex flex-nowrap gap-8 pb-8 overflow-x-auto snap-x snap-mandatory scrollbar-hide"
        >
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="flex-shrink-0 w-[calc(100%-48px)] md:w-[calc(50%-16px)] snap-start"
            >
              <div className="bg-[#1E1E2A] p-8 rounded-2xl h-full flex flex-col border border-white/10">
                <p className="font-bold text-white text-lg mb-4">{t.name}</p>
                <p className="text-gray-300 leading-relaxed">“{t.content}”</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex justify-end md:hidden">
          <div className="flex gap-4">
            <button
              onClick={() => scroll("left")}
              disabled={!canScrollLeft}
              className="p-3 rounded-full bg-[#1E1E2A] border border-white/10 text-white hover:bg-white/10 transition-colors disabled:opacity-50"
              aria-label="Scroll left"
              type="button"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <button
              onClick={() => scroll("right")}
              disabled={!canScrollRight}
              className="p-3 rounded-full bg-[#1E1E2A] border border-white/10 text-white hover:bg-white/10 transition-colors disabled:opacity-50"
              aria-label="Scroll right"
              type="button"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* CTA pós prova social */}
        <div className="mt-12 bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col md:flex-row gap-6 md:items-center md:justify-between">
          <div>
            <p className="text-white font-bold text-xl">Quer deixar sua rotina assim também?</p>
            <p className="text-gray-400 mt-1">
              Me chame no WhatsApp e eu te digo o melhor caminho para o seu caso.
            </p>
          </div>

          <button
            type="button"
            onClick={handleCTA}
            className="inline-flex items-center justify-center px-8 py-4 rounded-full bg-accent-purple text-white font-bold text-lg hover:bg-accent-purple/90 transition"
          >
            Falar no WhatsApp <ArrowUpRight className="ml-2 w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
