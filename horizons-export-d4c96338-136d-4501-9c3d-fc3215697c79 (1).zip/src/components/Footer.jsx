import React from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { blogPosts } from "@/data/blogPosts";

const Footer = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20direcionamento%20sobre%20contabilidade.";

  const handleWhatsApp = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  const scrollToId = (id) => {
    if (!id) {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const goHomeAndScroll = (id) => {
    if (location.pathname !== "/") {
      navigate("/");
      setTimeout(() => scrollToId(id), 140);
    } else {
      scrollToId(id);
    }
  };

  const handleAnchorClick = (e) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute("href") || "";
    const hashIndex = href.indexOf("#");
    const id = hashIndex >= 0 ? href.slice(hashIndex + 1) : "";
    goHomeAndScroll(id);
  };

  // 🔥 Link de serviço abre o acordeão correto via query param (?service=...)
  const handleServiceLink = (serviceSlug) => {
    const target = `/?service=${encodeURIComponent(serviceSlug)}#services`;

    if (location.pathname !== "/" || location.search !== `?service=${serviceSlug}` || location.hash !== "#services") {
      navigate(target);
      setTimeout(() => scrollToId("services"), 160);
    } else {
      // já está na home — só rola (Services vai ler a query e abrir)
      scrollToId("services");
    }
  };

  const latestPost =
    Array.isArray(blogPosts) && blogPosts.length
      ? [...blogPosts].sort((a, b) => new Date(b.date) - new Date(a.date))[0]
      : null;

  return (
    <footer className="bg-[#0C0D0D] border-t border-white/10 pt-16 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <p className="text-2xl font-bold text-white tracking-wider">
              SOS <span className="text-accent-purple">Contabilidade</span>
            </p>

            <p className="text-gray-400 mt-2 max-w-sm">
              Atendimento direto com contador, suporte rápido no WhatsApp e rotina organizada
              para você ter clareza e tranquilidade.
            </p>

            <button
              type="button"
              onClick={handleWhatsApp}
              className="mt-6 inline-flex items-center justify-center px-6 py-3 rounded-full bg-accent-purple text-white font-bold hover:bg-accent-purple/90 transition"
            >
              Falar no WhatsApp
            </button>

            <p className="text-gray-500 text-sm mt-3">
              Resposta rápida • Sem compromisso
            </p>

            {/* Mini CTA do Blog (último post) */}
            {latestPost && (
              <div className="mt-10 bg-white/5 border border-white/10 rounded-2xl p-5">
                <p className="text-white font-bold">Último artigo do blog</p>
                <p className="text-gray-400 mt-2 text-sm line-clamp-2">
                  {latestPost.title}
                </p>

                {latestPost.excerpt && (
                  <p className="text-gray-500 mt-2 text-sm line-clamp-2">
                    {latestPost.excerpt}
                  </p>
                )}

                <Link
                  to={`/blog/${latestPost.slug}`}
                  className="mt-4 inline-flex items-center justify-center w-full px-5 py-3 rounded-full bg-white/10 border border-white/20 text-white font-bold hover:bg-white/15 transition"
                >
                  Ler agora
                </Link>
              </div>
            )}
          </div>

          {/* Navegação */}
          <div>
            <p className="font-semibold text-white mb-5 uppercase tracking-wide">
              Navegação
            </p>
            <ul className="space-y-3">
              <li>
                <a
                  href="/#"
                  onClick={handleAnchorClick}
                  className="text-gray-400 hover:text-accent-purple transition-colors"
                >
                  Início
                </a>
              </li>
              <li>
                <a
                  href="/#services"
                  onClick={handleAnchorClick}
                  className="text-gray-400 hover:text-accent-purple transition-colors"
                >
                  Serviços
                </a>
              </li>
              <li>
                <a
                  href="/#stats-section"
                  onClick={handleAnchorClick}
                  className="text-gray-400 hover:text-accent-purple transition-colors"
                >
                  Como funciona
                </a>
              </li>
              <li>
                <a
                  href="/#about"
                  onClick={handleAnchorClick}
                  className="text-gray-400 hover:text-accent-purple transition-colors"
                >
                  Sobre
                </a>
              </li>
              <li>
                <a
                  href="/#testimonials"
                  onClick={handleAnchorClick}
                  className="text-gray-400 hover:text-accent-purple transition-colors"
                >
                  Depoimentos
                </a>
              </li>
              <li>
                <Link
                  to="/blog"
                  className="text-gray-400 hover:text-accent-purple transition-colors"
                >
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          {/* Serviços (clicáveis + abre acordeão) */}
          <div>
            <p className="font-semibold text-white mb-5 uppercase tracking-wide">
              Serviços
            </p>
            <ul className="space-y-3 text-gray-400">
              <li>
                <button
                  type="button"
                  onClick={() => handleServiceLink("imposto-de-renda")}
                  className="text-left hover:text-accent-purple transition-colors"
                >
                  Imposto de Renda
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleServiceLink("abertura-e-encerramento")}
                  className="text-left hover:text-accent-purple transition-colors"
                >
                  Abertura e Encerramento
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleServiceLink("contabilidade-empresarial")}
                  className="text-left hover:text-accent-purple transition-colors"
                >
                  Contabilidade Empresarial
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleServiceLink("departamento-pessoal")}
                  className="text-left hover:text-accent-purple transition-colors"
                >
                  Departamento Pessoal
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleServiceLink("bpo-financeiro")}
                  className="text-left hover:text-accent-purple transition-colors"
                >
                  BPO Financeiro
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleServiceLink("legalizacao")}
                  className="text-left hover:text-accent-purple transition-colors"
                >
                  Legalização
                </button>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <p className="font-semibold text-white mb-5 uppercase tracking-wide">
              Contato
            </p>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <p className="text-white font-bold text-lg">
                Quer um direcionamento rápido?
              </p>
              <p className="text-gray-400 mt-2">
                Me chame no WhatsApp e eu te digo o melhor caminho para o seu caso.
              </p>

              <button
                type="button"
                onClick={handleWhatsApp}
                className="mt-5 w-full inline-flex items-center justify-center px-6 py-3 rounded-full bg-white/10 border border-white/20 text-white font-bold hover:bg-white/15 transition"
              >
                Abrir WhatsApp
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 text-gray-500 text-sm">
          <p>
            © {new Date().getFullYear()} SOS Contabilidade. Todos os direitos reservados.
          </p>
          <p className="text-gray-600">
            São Paulo • Atendimento online e presencial (quando necessário)
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
