import React from "react";
import { motion, useReducedMotion } from "framer-motion";

const clientLogos = [
  { name: "META3 FACHADAS E REVESTIMENTOS" },
  { name: "DENER LINO PERSONAL TRAINER" },
  { name: "THAIS QUIRINO ODONTOLOGIA" },
  { name: "VANESSA SENA BEAUTY" },
  { name: "NAYE COMUNICAÇÕES" },
  { name: "LAVOR ODONTOLOGIA" },
  { name: "INFINITYART METAL" },
  { name: "ONE SECURITY" },
];

const marqueeLogos = [...clientLogos, ...clientLogos];

const TrustedClients = () => {
  const reduceMotion = useReducedMotion();

  const WHATSAPP_URL =
    "https://wa.me/5511932808687?text=Oi!%20Vi%20as%20empresas%20atendidas%20e%20quero%20uma%20proposta%20de%20contabilidade.%20Meu%20neg%C3%B3cio%20%C3%A9%20____.";

  const marqueeVariants = {
    animate: {
      x: ["0%", "-50%"],
      transition: {
        x: {
          repeat: Infinity,
          repeatType: "loop",
          duration: 30,
          ease: "linear",
        },
      },
    },
  };

  const handleWhatsApp = () => {
    window.open(WHATSAPP_URL, "_blank", "noopener,noreferrer");
  };

  return (
    <section className="py-20 bg-[#0C0D0D] border-t border-b border-[#1E1E2A] overflow-hidden">
      <div className="container mx-auto px-6 text-center">
        <p className="text-lg text-gray-300 mb-3 uppercase">
          Atendimento para diferentes tipos de negócios
        </p>

        <p className="text-sm text-gray-500 mb-10">
          Comércio • Serviços • Profissionais liberais • Saúde • Construção • Pessoa Física (IR)
        </p>

        <div className="relative w-full overflow-hidden" aria-label="Empresas atendidas">
          <motion.div
            className="flex w-max"
            variants={marqueeVariants}
            animate={reduceMotion ? undefined : "animate"}
          >
            {marqueeLogos.map((logo, index) => (
              <div
                key={index}
                className="flex-shrink-0 px-10 md:px-14 py-4 flex justify-center items-center"
              >
                <span className="text-white text-lg md:text-2xl font-semibold opacity-70 whitespace-nowrap">
                  {logo.name}
                </span>
              </div>
            ))}
          </motion.div>

          {/* Fade nas laterais */}
          <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-[#0C0D0D] to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-[#0C0D0D] to-transparent" />
        </div>

        <div className="mt-10">
          <button
            type="button"
            onClick={handleWhatsApp}
            className="text-gray-300 hover:text-white underline underline-offset-4 transition"
          >
            Quero uma proposta no WhatsApp
          </button>
        </div>
      </div>
    </section>
  );
};

export default TrustedClients;
