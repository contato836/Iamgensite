
import React, { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";

const WHATSAPP_URL =
  "https://wa.me/5511932808687?text=Oi!%20Quero%20um%20or%C3%A7amento%20de%20contabilidade.";

const ContactRedirect = () => {
  useEffect(() => {
    // substitui a página atual (evita voltar para /contact ao clicar "voltar")
    window.location.replace(WHATSAPP_URL);
  }, []);

  return (
    <div className="min-h-[60vh] bg-[#0C0D0D] text-white flex items-center justify-center px-6">
      <div className="text-center">
        <p className="text-xl font-bold">Redirecionando para o WhatsApp…</p>
        <p className="text-gray-400 mt-2">Se não abrir automaticamente, clique abaixo.</p>

        <a
          className="inline-flex items-center justify-center mt-6 px-6 py-3 rounded-full bg-accent-purple text-white font-bold hover:bg-accent-purple/90 transition"
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
        >
          Abrir WhatsApp
        </a>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />

        {/* Blog */}
        <Route path="blog" element={<Blog />} />
        <Route path="blog/:slug" element={<BlogPost />} />

        {/* “Contato” vira WhatsApp */}
        <Route path="contact" element={<ContactRedirect />} />

        {/* Rotas inválidas -> Home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
};

export default App;
